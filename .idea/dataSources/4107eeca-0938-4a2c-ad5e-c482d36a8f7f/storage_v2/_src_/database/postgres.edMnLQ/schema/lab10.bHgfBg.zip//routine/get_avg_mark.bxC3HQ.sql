create function get_avg_mark(subject character varying) returns real
    language plpgsql
as
$$
    DECLARE avg_mark real;
    begin
        select avg(progress.mark) into avg_mark from progress join subjects on progress.subject_id = subjects.id
        where subjects.subject_name = subject;
        return avg_mark;
    end;
    $$;

alter function get_avg_mark(varchar) owner to postgres;

